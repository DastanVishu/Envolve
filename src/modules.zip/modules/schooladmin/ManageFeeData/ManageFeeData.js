import React, {Component} from 'react';

class ManageFeeData extends Component {
    render() {
        return(
            <div>
                ManageFeeData
            </div>
        )
    }
}

export default ManageFeeData;